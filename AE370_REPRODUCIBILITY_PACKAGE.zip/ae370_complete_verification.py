"""AE 370 — Complete Numerical Calculations & Reproducibility Check
==================================================================
Project: Numerical Analysis of Rocket Ascent Under Variable Mass,
         Atmospheric Drag, and Gravity
Group: Eric Acree, John McLane, Brayden Glassman, Joshua Yang

Run from VS Code / a terminal:
    pip install numpy matplotlib
    python ae370_complete_verification.py

Every result is computed anew. No pre-stored curve points are used.
The program creates five PDF graphs used in Overleaf and
"ae370_calculation_audit.txt", which contains the numerical values and checks.

SECTION 1 — EQUATIONS, SI UNITS, AND ASSUMPTIONS
  State y(t) = [h (m), v (m/s), m (kg)].
  h' = v
  v' = [T - D(h,v)]/m - g(h)
  m' = -mdot
  Density = rho0 exp(-h/H)                 [kg/m^3]
  Drag = (1/2) density Cd A v |v|         [N, signed]
  Gravity = g0 (Re/(Re+h))^2               [m/s^2]
  Powered phase: T = T0, mdot = mdot0
  Coasting phase: T = mdot = 0
  Burnout time tb = (m0-md)/mdot0          [s]
  Initial thrust/weight = T0/(m0*g0)      [dimensionless]
  Propellant fraction phi = (m0-md)/m0    [dimensionless]

SECTION 2 — CLASSICAL EXPLICIT RK4 (IMPLEMENTED FROM SCRATCH)
  k1 = f(t, y)
  k2 = f(t+dt/2, y+dt*k1/2)
  k3 = f(t+dt/2, y+dt*k2/2)
  k4 = f(t+dt, y+dt*k3)
  y_next = y + dt*(k1+2*k2+2*k3+k4)/6
  The four stages satisfy eight fourth-order Butcher conditions.
  On smooth portions the one-step error is O(dt^5) and accumulated
  global error is O(dt^4), assuming sufficient regularity/stability.
  Burnout is treated as an exact phase boundary; no RK4 step crosses it.
  The apogee zero of velocity is bracketed and located by bisection,
  using RK4 trials starting from the same left-side state.

SECTION 3 — INDEPENDENT VERIFICATION & COST
  With D=0 and g=g0, the rocket has exact powered-flight formulas:
      m(t) = m0-mdot*t
      v(t) = T0/mdot*ln(m0/m(t))-g0*t
      h(t) = T0/mdot^2*[m0-m(t)-m(t)*ln(m0/m(t))]-g0*t^2/2.
  The burnout altitude/velocity are checked against these formulas.
  Log-log global error order: p=log2(E(dt)/E(dt/2)).
  With fixed flight duration, RK4 costs 4 RHS evaluations per step;
  the bisection event finder adds extra trial RK4 calls.

SECTION 4 — PARAMETER STUDIES & SENSITIVITIES
  Study A: change T0 to set TWR0, with other parameters unchanged.
  Study B: change Cd, with area and other parameters unchanged.
  Study C: change md=m0*(1-phi), with m0 and mdot unchanged. Thus
           burnout time also changes when phi changes.
  Dimensionless local sensitivity uses centered relative perturbations:
     Sx = [h(x0*(1+eps))-h(x0*(1-eps))]/[2*eps*h(x0)].
  The script repeats this with eps=0.02, 0.01, 0.005 and dt=0.05.

STABILITY — NEGATIVE REAL MODE ANALYSIS
  For the scalar test y'=lambda*y, RK4 amplification is
     R(z) = 1+z+z^2/2+z^3/6+z^4/24; z=lambda*dt.
  |R(z)| <= 1 defines the absolute stability region.
  On the negative real axis this is approximately -2.7853 <= z <= 0.
  The rocket Jacobian is sampled on trajectories to estimate a
  conservative step for its decaying (negative) eigenmode.
  This is local guidance only, NOT proof of stability for the
  complete nonlinear/time-varying system, and not an error estimate.

This is a simplified mathematical model, NOT experimental flight data.
No outside ODE integrator (including scipy.solve_ivp) is used.
"""
from dataclasses import dataclass, replace
from pathlib import Path
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUTPUT = Path(__file__).resolve().parent
DT = 0.1
EVENT_TOL = 1e-10

@dataclass(frozen=True)
class Params:
    m0: float = 100.0
    md: float = 40.0
    T: float = 3000.0
    flow: float = 2.0
    Cd: float = 0.5
    A: float = 0.05
    rho0: float = 1.225
    H: float = 8500.0
    g0: float = 9.81
    Re: float = 6.371e6

    @property
    def tb(self):
        return (self.m0-self.md)/self.flow

    @property
    def twr(self):
        return self.T/(self.m0*self.g0)

    @property
    def phi(self):
        return (self.m0-self.md)/self.m0

def density(h,p):
    return p.rho0*math.exp(-h/p.H)

def gravity(h,p):
    return p.g0*(p.Re/(p.Re+h))**2

def drag(h,v,p):
    return 0.5*density(h,p)*p.Cd*p.A*v*abs(v)

def derivative(t,y,p,powered,analytic_model=False):
    h,v,m=y
    D=0 if analytic_model else drag(h,v,p)
    g=p.g0 if analytic_model else gravity(h,p)
    thrust=p.T if powered else 0.0
    mdot=p.flow if powered else 0.0
    # h'=v; v'=(thrust-signed_drag)/mass-gravity; m'=-mdot
    return np.array([v,(thrust-D)/m-g,-mdot])

def rk4(t,y,dt,p,powered,analytic_model=False):
    # Classical RK4, four evaluations of the right-hand side.
    f=lambda time,state: derivative(time,state,p,powered,analytic_model)
    k1=f(t,y)
    k2=f(t+dt/2,y+dt*k1/2)
    k3=f(t+dt/2,y+dt*k2/2)
    k4=f(t+dt,y+dt*k3)
    return y+dt*(k1+2*k2+2*k3+k4)/6

def simulate(p,dt=DT,store=False,analytic_model=False):
    t=0.0
    y=np.array([0.0,0.0,p.m0])
    times=[t]; states=[y.copy()]
    steps=0
    # Finish powered flight exactly at burnout: no mixed-phase RK4 step.
    # The endpoint derivative at tb uses the powered-side limiting field;
    # only the next step, after the switch, uses coasting dynamics.
    while t < p.tb-1e-12:
        d=min(dt,p.tb-t)
        y=rk4(t,y,d,p,True,analytic_model)
        t+=d; steps+=1
        if store: times.append(t); states.append(y.copy())
    t=p.tb
    y[2]=p.md
    burn=y.copy()
    if store: times[-1]=t; states[-1]=y.copy()
    if y[1]<=0: raise RuntimeError("No upward coasting phase")
    # Coast until the first velocity sign change.
    while t < 2000:
        yn=rk4(t,y,dt,p,False,analytic_model)
        steps+=1
        if y[1]>0 and yn[1]<=0:
            # Bisection: every trial RK4 starts at the same left state.
            lo,hi=0.0,dt
            iterations=0
            while hi-lo>EVENT_TOL:
                mid=(lo+hi)/2
                test=rk4(t,y,mid,p,False,analytic_model)
                if test[1]>0: lo=mid
                else: hi=mid
                iterations+=1
            tau=(lo+hi)/2
            apex=rk4(t,y,tau,p,False,analytic_model)
            if store:
                times.append(t+tau); states.append(apex.copy())
            return dict(burn=burn,apex=apex,ta=t+tau,steps=steps,
                        iterations=iterations,times=np.array(times),
                        states=np.array(states))
        t+=dt; y=yn
        if store: times.append(t); states.append(y.copy())
    raise RuntimeError("Apogee not found")

def analytical_burnout(p):
    # Exact powered-flight solution ONLY for D=0 and g=g0.
    t=p.tb
    m=p.m0-p.flow*t
    v=p.T/p.flow*math.log(p.m0/m)-p.g0*t
    h=p.T/p.flow**2*(p.m0-m-m*math.log(p.m0/m))-0.5*p.g0*t*t
    return np.array([h,v,m])

def numerical_burnout(p,dt):
    t=0.0; y=np.array([0.,0.,p.m0])
    while t<p.tb-1e-12:
        d=min(dt,p.tb-t)
        y=rk4(t,y,d,p,True,True)
        t+=d
    return y

def jacobian(y,p,powered):
    h,v,m=y
    D=drag(h,v,p)
    g=gravity(h,p)
    T=p.T if powered else 0.
    ah=D/(m*p.H)+2*g/(p.Re+h)
    av=-density(h,p)*p.Cd*p.A*abs(v)/m
    am=-(T-D)/m**2
    return np.array([[0,1,0],[ah,av,am],[0,0,0]],float)

def rk4_stability(z):
    # For u'=lambda*u, numerical amplification is R(lambda*dt).
    return 1+z+z*z/2+z**3/6+z**4/24

def stability_boundary():
    # Solve R(-x)=1, x>0, by bisection.
    lo,hi=2.,3.
    for _ in range(80):
        mid=(lo+hi)/2
        if rk4_stability(-mid)>1: hi=mid
        else: lo=mid
    return (lo+hi)/2

def stability_sample(p):
    r=simulate(p,DT,store=True)
    values=[]
    for t,y in zip(r["times"],r["states"]):
        modes=[True,False] if abs(t-p.tb)<1e-8 else [t<p.tb]
        for powered in modes:
            J=jacobian(y,p,powered)
            ah,av=J[1,0],J[1,1]
            negative=(av-math.sqrt(av*av+4*ah))/2
            values.append(abs(negative))
    largest=max(values)
    return largest,stability_boundary()/largest

def check_rk4_order_conditions():
    # Eight rooted-tree conditions for classical fourth-order RK.
    A=np.array([[0,0,0,0],[.5,0,0,0],[0,.5,0,0],[0,0,1,0]])
    b=np.array([1/6,1/3,1/3,1/6])
    c=np.array([0,.5,.5,1.])
    actual=[b@np.ones(4),b@c,b@(c*c),b@A@c,b@(c**3),
            b@A@(c*c),b@np.diag(c)@A@c,b@A@A@c]
    expected=[1,1/2,1/3,1/6,1/4,1/12,1/8,1/24]
    return list(zip(actual,expected))

def plot_results(baseline,steps,errors,studies):
    fig,axes=plt.subplots(3,1,figsize=(9,10),sharex=True)
    for i,label in enumerate(["Altitude (m)","Velocity (m/s)","Mass (kg)"]):
        axes[i].plot(baseline["times"],baseline["states"][:,i])
        axes[i].axvline(Params().tb,ls="--",label="Burnout")
        axes[i].set_ylabel(label); axes[i].grid(True); axes[i].legend()
    axes[-1].set_xlabel("Time (s)")
    fig.tight_layout(); fig.savefig(OUTPUT/"rocket_trajectory.pdf")
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,5))
    ax.loglog(steps,errors,"o-",label="Burnout altitude error")
    ax.set(xlabel="Time step (s)",ylabel="Absolute error (m)")
    ax.grid(True,which="both"); ax.legend()
    fig.tight_layout(); fig.savefig(OUTPUT/"rocket_convergence.pdf")
    plt.close(fig)
    for name,x,h,label in studies:
        fig,ax=plt.subplots(figsize=(8,5))
        ax.plot(x,np.array(h)/1000,"o-")
        ax.set(xlabel=label,ylabel="Maximum altitude (km)")
        ax.grid(True,alpha=.3)
        fig.tight_layout(); fig.savefig(OUTPUT/name)
        plt.close(fig)

def main():
    p=Params()
    lines=[]
    def say(msg=""):
        print(msg); lines.append(str(msg))
    say("AE 370 — REPRODUCIBLE NUMERICAL CALCULATION AUDIT")
    say(f"NumPy version: {np.__version__}; Matplotlib version: {matplotlib.__version__}")
    say("Source: accompanying AE 370 Overleaf report; units SI")
    say("ODE: y=[h,v,m], y'=[v,(T-D)/m-g,-mdot]")
    say("rho=rho0 exp(-h/H); g=g0(Re/(Re+h))^2; D=0.5*rho*Cd*A*v*abs(v)")
    say("Powered: T=3000 N, mdot=2 kg/s. Coast: T=mdot=0.")
    say(f"Burnout=(m0-md)/mdot={p.tb:.6f} s")
    say(f"Initial TWR=T/(m0*g0)={p.twr:.9f}; phi=(m0-md)/m0={p.phi:.6f}")
    say("RK4: k1=f(t,y); k2=f(t+dt/2,y+dt*k1/2);")
    say("k3=f(t+dt/2,y+dt*k2/2); k4=f(t+dt,y+dt*k3)")
    say("y_next=y+dt*(k1+2*k2+2*k3+k4)/6")
    say("Local unnormalized error O(dt^5); global error O(dt^4) on smooth phases.")
    say("Burnout is an exact integration boundary; apogee is refined by bisection.")
    say()
    say("RK4 ORDER CONDITIONS: computed, required")
    for a,b in check_rk4_order_conditions():
        say(f" {a:.12f}, {b:.12f}")
        assert abs(a-b)<1e-12
    say()
    baseline=simulate(p,DT,store=True)
    say("BASELINE (dt=0.10 s)")
    say(f" Burnout altitude = {baseline['burn'][0]:.9f} m (report 8844.76)")
    say(f" Burnout velocity = {baseline['burn'][1]:.9f} m/s (report 568.53)")
    say(f" Burnout mass = {baseline['burn'][2]:.9f} kg")
    say(f" Apogee altitude = {baseline['apex'][0]:.9f} m (report 16114.61)")
    say(f" Apogee time = {baseline['ta']:.9f} s (report 64.93)")
    say(f" Ordinary RK4 steps={baseline['steps']}, event bisections={baseline['iterations']}")
    say(f" Approx RHS calls={4*(baseline['steps']+baseline['iterations']+1)}")
    assert abs(baseline['burn'][0]-8844.76)<.02
    assert abs(baseline['burn'][1]-568.53)<.02
    assert abs(baseline['apex'][0]-16114.61)<.02
    assert abs(baseline['ta']-64.93)<.02
    say(" Baseline matches report values to their displayed precision")
    say()
    say("ANALYTICAL CHECK: no drag, constant gravity")
    say("m=m0-mdot*t")
    say("v=(T/mdot)*ln(m0/m)-g0*t")
    say("h=(T/mdot^2)*(m0-m-m*ln(m0/m))-0.5*g0*t^2")
    exact=analytical_burnout(p)
    steps=np.array([.8,.4,.2,.1,.05])
    errors=[]
    for dt in steps:
        num=numerical_burnout(p,dt)
        eh=abs(num[0]-exact[0]); ev=abs(num[1]-exact[1])
        errors.append(eh)
        say(f" dt={dt:.2f}: altitude error={eh:.9e} m, velocity error={ev:.9e} m/s")
    for i in range(len(steps)-1):
        if errors[i]>0 and errors[i+1]>0:
            order=math.log(errors[i]/errors[i+1],2)
            say(f" observed order {steps[i]:.2f}->{steps[i+1]:.2f}: {order:.5f}")
    mid_order=math.log(errors[1]/errors[2],2)
    assert abs(mid_order-4)<.03, "Expected fourth-order convergence not observed"
    say(" At tiny errors floating-point roundoff may obscure order 4.")
    say()
    say("FULL MODEL REFINEMENT")
    full={}
    for dt in steps:
        full[dt]=simulate(p,dt)["apex"][0]
        say(f" dt={dt:.2f}: apogee={full[dt]:.9f} m")
    say(f" Change 0.10 -> 0.05 s: {abs(full[.1]-full[.05]):.9e} m")
    say(" Target change < 0.01 m")
    say()
    say("PARAMETER STUDIES: each row recomputed with RK4")
    study_data=[]
    configurations=[
      ("rocket_twr_study.pdf","Initial thrust-to-weight ratio",
       np.array([1.5,2,2.5,p.twr,3.5,4]),
       lambda x: replace(p,T=x*p.m0*p.g0),
       [5362.37,8638.57,12003.94,16114.61,19812,24699.25]),
      ("rocket_drag_study.pdf","Drag coefficient",
       np.array([0,.25,.5,.75,1]),
       lambda x: replace(p,Cd=x),
       [73413.34,26575.84,16114.61,12149.05,10048.62]),
      ("rocket_mass_study.pdf","Propellant mass fraction",
       np.array([.4,.5,.6,.7,.8]),
       lambda x: replace(p,md=p.m0*(1-x)),
       [8305.25,11805.44,16114.61,21701.64,29366.97])]
    for filename,label,values,change,reported in configurations:
        say(" "+label)
        altitudes=[]
        for x,ref in zip(values,reported):
            case=change(float(x))
            result=simulate(case)
            altitude=result["apex"][0]
            altitudes.append(altitude)
            difference=altitude-ref
            status="MATCH" if abs(difference)<.03 else "CHECK REPORT"
            if status != "MATCH":
                raise AssertionError(f"Report table discrepancy in {label} at x={x}")
            say(f"  x={x:.8f}: apogee={altitude:.6f} m, "
                f"burnout_v={result['burn'][1]:.6f} m/s, "
                f"tb={case.tb:.3f} s; report={ref:.2f}; "
                f"delta={difference:+.5f} [{status}]")
        study_data.append((filename,values,altitudes,label))
    say()
    say("PARAMETER-STUDY TIME-STEP CHECK (dt=0.10 vs dt=0.05 s)")
    max_refinement=0.0
    worst_case=""
    for _,label,values,change,_ in configurations:
        for x in values:
            case=change(float(x))
            coarse=simulate(case,.10)["apex"][0]
            fine=simulate(case,.05)["apex"][0]
            discrepancy=abs(coarse-fine)
            if discrepancy>max_refinement:
                max_refinement=discrepancy
                worst_case=f"{label}={x:.8f}"
    say(f" Maximum refinement difference = {max_refinement:.9e} m")
    say(f" Largest-difference case = {worst_case}")
    say(" Required: < 0.01 m for the performance-table precision")
    assert max_refinement < .01, "Parameter study failed step refinement"
    say()
    say("LOCAL SENSITIVITIES: S=[h(x0*(1+eps))-h(x0*(1-eps))]/(2*eps*h0)")
    def sensitivity(index,eps,dt):
        _,_,values,change,_=configurations[index]
        baseline_x=[p.twr,p.Cd,p.phi][index]
        hplus=simulate(change(baseline_x*(1+eps)),dt)["apex"][0]
        hminus=simulate(change(baseline_x*(1-eps)),dt)["apex"][0]
        hbase=simulate(p,dt)["apex"][0]
        return (hplus-hminus)/(2*eps*hbase)
    for i,label in enumerate(["TWR","Cd","phi"]):
        for eps in [.02,.01,.005]:
            say(f" {label}, eps={eps}: S={sensitivity(i,eps,DT):.8f}")
        say(f" {label}, dt refinement difference: "
            f"{abs(sensitivity(i,.005,.1)-sensitivity(i,.005,.05)):.9e}")
    say()
    say("ABSOLUTE STABILITY AND JACOBIAN")
    say("R(z)=1+z+z^2/2+z^3/6+z^4/24, z=lambda*dt")
    say("Stable decaying test modes satisfy |R(z)|<=1.")
    say(f" Negative real stability boundary = {-stability_boundary():.12f}")
    say("J=[[0,1,0],[ah,av,am],[0,0,0]]")
    say("ah=D/(mH)+2g/(Re+h); av=-rho*Cd*A*|v|/m; am=-(T-D)/m^2")
    say("Eigenvalues = 0, (av +/- sqrt(av^2+4ah))/2")
    for label,case in [
        ("baseline",p),
        ("TWR=1.5",replace(p,T=1.5*p.m0*p.g0)),
        ("TWR=4.0",replace(p,T=4*p.m0*p.g0)),
        ("Cd=0",replace(p,Cd=0)),
        ("Cd=1",replace(p,Cd=1)),
        ("phi=0.4",replace(p,md=60)),
        ("phi=0.8",replace(p,md=20))]:
        lam,limit=stability_sample(case)
        say(f" {label}: max |negative eigenvalue|={lam:.8f} 1/s, "
            f"dt_neg={limit:.6f} s")
    say("Positive eigenvalues can describe physical local growth.")
    say("Sampled Jacobian stability is guidance, not proof of nonlinear stability.")
    say()
    say("PLOTS AND AUDIT")
    plot_results(baseline,steps,errors,study_data)
    for name in ["rocket_trajectory.pdf","rocket_convergence.pdf",
                 "rocket_twr_study.pdf","rocket_drag_study.pdf",
                 "rocket_mass_study.pdf"]:
        say(" "+name)
    say("Assumptions: vertical motion; fixed thrust, flow, Cd and area per case;")
    say("exponential atmosphere; inverse-square gravity; no wind or staging.")
    say("TWR variation changes effective exhaust velocity T/mdot.")
    say("Propellant-fraction variation changes both dry mass and burn duration.")
    say("Event bisection tolerance is NOT total trajectory error.")
    (OUTPUT/"ae370_calculation_audit.txt").write_text("\n".join(lines)+"\n")
    say("Saved ae370_calculation_audit.txt")

if __name__=="__main__":
    main()
